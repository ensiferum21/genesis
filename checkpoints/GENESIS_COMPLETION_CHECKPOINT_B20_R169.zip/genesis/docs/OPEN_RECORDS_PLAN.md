# The open-record track: Gset max-cut (B20_R101 onward; DRAFT plan)

Daniel's ask of 22 Oct 2026 ("get inspired by the reality and make it extremely good") applied to one weakness:
every Genesis result so far is on hosts generated for its own studies. There, the best values are either reached
by every method (planted n63; development looks in `docs/DISCOVERY_PLAN.md` §3.1) or known only to the study itself.
A result on a public benchmark with published best-known values cannot be argued away that way. Nothing here is
preregistered.

## 1. Why Gset max-cut

- **Public and long-standing.** Gset G1–G54 (Helmberg and Rendl 2000, rudy generator; 800–3,000 vertices; random,
  planar and toroidal graphs, weights ±1) has been the standard max-cut benchmark for 25 years. Best-known values
  are published, and the methods that set them are published too: Burer, Monteiro and Zhang 2001 (BURER2002, already
  a pinned Genesis arm through MQLib), breakout local search (Benlic and Hao 2013), and later records.
- **The physics-inspired machines report on it.** Simulated bifurcation (Goto et al. 2019, 2021; `ising-dsb-v1` is
  its discrete form), coherent Ising machines and other Ising hardware publish time-to-target on G22, G39 and others.
  This is the "reality" comparison the physics plan (`docs/PHYSICS_INSPIRED_PLAN.md`) points to. Hardware
  differences must be stated: the published numbers come from GPUs, FPGAs and optical machines; ours are one CPU
  core.
- **It fits what exists.** Max cut is the cut representation Genesis already invented and licensed (`cross_2`, B18).
  The language programs (B20_R78 onward), dSB, BURER2002 and the tabu and extremal-optimization kinds all search
  cuts. Only the completion step (cut to triangle-free subgraph) is specific to the current domain.
- **It is a harder playground for the discovery loop.** Gset graphs are sparse and structured (toroidal grids,
  planar graphs). Local objects there, such as frustrated cycles and domain walls, are the kind of structure the
  note's loop is meant to find.

## 2. What it needs

1. **Data.** `set1.zip` (G1–G54) and `maxcut_bestvalues.xls` from the OPTSICOM max-cut page
   (grafo.etsii.urjc.es/maxcut). The workspace's proxy refuses the site, so Daniel downloaded them on 22 Oct 2026:
   `set1.zip` SHA-256 `18e00bfc…2e71` (54 well-formed instances, sizes as published) and `maxcut_bestvalues.xls`
   `1831bdc4…c018`. The spreadsheet is OPTSICOM's 2009 table; Benlic and Hao's breakout local search (2013) has since
   improved 18 of G1–G54 (for example G27 3341, G39 2408), so the best-known value per instance is the highest
   published one, with its source, cross-checked against the paper before any comparison.
2. **A domain `maxcut_v1` (engineering).** An adapter for weighted graphs up to 10,000 vertices, an exact cut-value
   checker in integers, and witness custody as in `triangle_free_large_v1`. Certification is out of scope: best-known
   values are lower bounds, and an upper bound would need an SDP. Results are stated against best-known values,
   never as optimality.
3. **Arms.**
   - BURER2002 (MQLib, pinned).
   - dSB.
   - The system's language programs run on the cut alone (the program's state without the completion step).
   - The builder's engine core (tightness-guided search, from `tfxw`), adapted to cuts, as a separate engine, never
     relabelled as the system's discovery.

## 3. Studies (to be preregistered one at a time)

- **B20_R101, engineering:** the domain, the data, the arms, tests (a hand-checked cut value per instance family).
- **B20_R102, where Genesis stands against the records:** fraction of best-known value and time-to-target at 1, 10
  and 60 s on G1–G54, against BURER2002 at equal time, and against published Ising-machine numbers as a stated
  external reference (different hardware, so not a paired comparison).
  **Result (23 Oct 2026):** the best of 12 published heuristics at 10 s reaches 0.99675 of the 2012-13 best known
  values; dSB is the best single tool (0.99618), BURER2002 0.99537; no record candidate (`evidence/gset_standing_b20r102/`).
- **B20_R104, engineering:** Genesis's own max-cut engine, `mcx-v1` (iterated tabu search in the manner of breakout
  local search; an elite pool; restarts by a Houdayer cluster exchange or by renormalisation, which contracts every
  edge the elites agree on and searches the contracted problem), from source, pinned; graph families built as Gset's
  were (rudy's planar unions, rectangular tori), so that configuring never needs Gset.
- **B20_R105, the system configures the engine on generated graphs only:** two order parameters of the degree
  sequence place a graph in a class (random, toroidal, planar); per class and budget, successive halving over 32
  configurations on fresh graphs; held-out check against the default and BURER2002.
  **Result:** the system's choice beats BLS's published setting at 1 s and ties it at 10 s; both budgets ahead of
  BURER2002 on 24 held-out generated graphs (22-0, 17-2); `evidence/mcx_configure_b20r105/`.
- **B20_R106, once on Gset:** the configured engine at 1 s and 10 s on G1–G54 against B20_R102's recorded runs
  (BURER2002, dSB, the virtual best of twelve heuristics), sign tests; values above the table are flagged, never
  claimed. All three preregistered before B20_R102 ran.
  **Result (23 Oct 2026): MCX_LEADS.** Ahead of BURER2002, dSB and the virtual best of 12 published heuristics at
  both budgets; 0.99860 of the best known values at 10 s, reaching them on 24 of 54; no record
  (`evidence/mcx_gset_b20r106/`). Next: more seeds, longer budgets against the best known values.
  **B20_R109: REPLICATED** with three seeds per arm (47-3 against BURER2002, 47-2 against dSB; best known values
  reached on 30 of 54; `evidence/gset_replication_b20r109/`).
  **B20_R110:** at 60 s, the best known values reached on 27 of 54, every torus included; 0.99912 on average; no
  record. The remaining gap is the larger planar +-1 graphs (G39-G42).
  **B20_R113: RENORM_BETTER.** B20_R108's renormalisation configuration beats B20_R105's planar choice on 40 fresh
  planar graphs (25-8) and on Gset's 20 planar instances at 60 s (13-2), reaching the best known values on 5 of
  them (3 before); 29 of 54 Gset instances at 60 s, 33 over all recorded runs; no record
  (`evidence/planar_renorm_b20r113/`). Next, B20_R116: five minutes on each of the 21 instances not yet reached.
  **B20_R116:** five minutes on each of those 21 reached 7 more: **40 of 54 over all recorded runs, none exceeded**;
  11 of the 14 left are one unit short (`evidence/gset_attempt_b20r116/`). A record attempt would need several
  seeds and a configuration chosen at the long budget on the 2,000-vertex planar instances, and a check against
  the literature after 2013.
  **B20_R123:** three more seeds on the 14 left reached 5: **45 of 54 matched, none beaten.** Two cuts of 7688 on
  G38, above the max-cut papers' 7687, were already known from the max-bisection literature (Wu and Hao 2013): no
  record; the table now holds bisection lower bounds, and each source the time it was added
  (`evidence/gset_seeds_b20r123/`).
- **Then the discovery loop on Gset**, if B20_R99 finds structured headroom. The test is whether concepts invented
  on toroidal and planar instances transfer to random ones, and the reverse. That is the note's "untouched family"
  inside one public benchmark.

## 4. Honesty rules for this track

- A Gset record claim requires the witness cut, its re-check, the instance's SHA-256, and the published best-known
  value with its source.
- Time comparisons with published hardware results are descriptive only.
- Losing to BURER2002 or to the records is a result, recorded as such.
