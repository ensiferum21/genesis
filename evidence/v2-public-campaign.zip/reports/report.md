# Genesis executed development campaign

**No scientific promotion. All results are public development diagnostics.**

| Generation | Candidate / baseline wins / ties | Adaptive / uniform wins / ties | Transfer wins / losses / ties |
|---|---|---|---|
| 0 | 2 / 0 / 6 | 0 / 0 / 8 | 0 / 0 / 8 |
| 1 | 0 / 0 / 8 | 0 / 0 / 8 | 1 / 0 / 7 |
| 2 | 0 / 0 / 8 | 0 / 0 / 8 | 1 / 2 / 5 |

Executed attempts, including exact-check attempts: 600.

## Limitations

- All panels public and locally generated
- Fixed bounded candidate grammar
- Exact solver is an evaluation reference, not a matched heuristic competitor
- CPU limits matched; observed wall/CPU costs may differ
- Discovery and checking costs separately ledgered
- No Lean executable or arbitrary-code sandbox required by this data-only route
- No novelty or recursive-improvement claim
